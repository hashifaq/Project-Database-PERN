import React, {useState, Fragment} from "react";
import './App.css';

//components

import InputBook from "./components/InputBook";
import ListBooks from "./components/ListBook";
import SqlBuilder from "./components/sqlbuilder";

function App() {
  const [sql, isSql] = useState(false);

  return ( 
    <Fragment>
      <div className="container">
        <InputBook></InputBook>
        <ListBooks></ListBooks>
        <SqlBuilder />

      </div>
    </Fragment>
  );
}

export default App;
