import React, { Fragment, useState } from "react";
import { BiEdit, BiTrashAlt, BiUserPlus } from "react-icons/bi"

const InputBook = () => {
  const [title, setTitle] = useState("");
  const [publication_year, setPublication_year] = useState("");
  const [num_pages, setNum_pages] = useState("");
  const [price, setPrice] = useState("");
  const [isSubmitOpen, setIsSubmitOpen] = useState(false);

  const onSubmitForm = async (e) => {
    e.preventDefault();
    if (!title || !publication_year || !num_pages || !price) {
      alert("Mohon isi data dengan benar");
      return;
    }
    try {
      const body = { title, publication_year, num_pages, price };
      const response = await fetch("http://localhost:8080/books", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      window.location = "/";
    } catch (err) {
      console.error(err.message);
    }
  };

  return (
    <Fragment>
      <h1 className="text-center mt-5 mb-5">Kalu Bookstore</h1>
      <button
        onClick={() => { setIsSubmitOpen(true);}}
        className="btn mt-2 mb-4"
        style={{ backgroundColor: '#93C5FD', color: 'black' }}
      >
        Add <BiUserPlus size={24} />
      </button>


      {isSubmitOpen ? (
      <form className="grid lg:grid-cols-2 w-4/6 gap-8 mb-7" onSubmit={onSubmitForm}>
        <input
          type="text"
          placeholder="Title"
          className="border rounded py-2 px-3 mr-2 form-control w-full lg:w-auto"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <input
          type="text"
          placeholder="Publication Year"
          className="border rounded py-2 px-3 mr-2 mt-2 form-control w-full lg:w-auto"
          value={publication_year}
          onChange={(e) => setPublication_year(e.target.value)}
        />
        <input
          type="text"
          placeholder="Pages"
          className="border rounded py-2 px-3 mr-2 mt-2 form-control w-full lg:w-auto"
          value={num_pages}
          onChange={(e) => setNum_pages(e.target.value)}
        />
        <input
          type="text"
          placeholder="Price"
          className="border rounded py-2 px-3 mr-2 mt-2 form-control w-full lg:w-auto"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
        <button 
          className="btn mt-2"
          style={{ backgroundColor: '#93C5FD', color: 'black' }}
        >Add New Book</button>
      </form>
      ) : ("") }
    </Fragment>
  );
};

export default InputBook;
