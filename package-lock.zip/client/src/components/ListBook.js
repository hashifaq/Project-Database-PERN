import React, { Fragment, useEffect, useState } from "react";
import { BiEdit, BiTrashAlt, BiUserPlus } from "react-icons/bi"
import EditBook from "./EditBook";

const ListBooks = () => {
  const [books, setBooks] = useState([]);

  //delete book function

  const deleteBook = async id => {
    try {
      const deleteBook = await fetch(`http://localhost:8080/books/${id}`, {
        method: "DELETE"
      });

      setBooks(books.filter(book => book.book_id !== id));
    } catch (err) {
      console.error(err.message);
    }
  };

  const getBooks = async () => {
    try {
      const response = await fetch("http://localhost:8080/books");
      const jsonData = await response.json();

      setBooks(jsonData);
    } catch (err) {
      console.error(err.message);
    }
  };

  useEffect(() => {
    getBooks();
  }, []);

  return (
    <Fragment>
      {" "}
      <table style={{ minWidth: '100%', tableLayout: 'auto' }} className="table mt-5 text-center">
        <thead>
            <tr style={{ backgroundColor: '#F3F4F6', textAlign: 'center' }}>
              <th style={{ backgroundColor: '#1F2937', paddingTop: '0.5rem', paddingBottom: '0.5rem', color: '#F9FAFB', paddingLeft: '1rem', paddingRight: '1rem' }}>Title</th>
              <th style={{ backgroundColor: '#1F2937', paddingTop: '0.5rem', paddingBottom: '0.5rem', color: '#F9FAFB', paddingLeft: '1rem', paddingRight: '1rem' }}>Publication Year</th>
              <th style={{ backgroundColor: '#1F2937', paddingTop: '0.5rem', paddingBottom: '0.5rem', color: '#F9FAFB', paddingLeft: '1rem', paddingRight: '1rem' }}> Pages</th>              
              <th style={{ backgroundColor: '#1F2937', paddingTop: '0.5rem', paddingBottom: '0.5rem', color: '#F9FAFB', paddingLeft: '1rem', paddingRight: '1rem' }}>Price</th>
              <th style={{ backgroundColor: '#1F2937', paddingTop: '0.5rem', paddingBottom: '0.5rem', color: '#F9FAFB', paddingLeft: '1rem', paddingRight: '1rem' }}>Actions</th>
            </tr>
        </thead>
        <tbody>
          {books.map(book => (
            <tr key={book.book_id}>
              <td>{book.title}</td>
              <td>{book.publication_year}</td>
              <td>{book.num_pages}</td>
              <td>{book.price}</td>
              <td>
                <EditBook book={book} />
                <button
                  className="btn btn-danger"
                  style={{ marginLeft: '45px' }}
                  onClick={() => deleteBook(book.book_id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Fragment>
  );
};

export default ListBooks;



// import React, { Fragment, useEffect, useState } from "react";

// import EditBook from "./EditBook";

// const ListBooks = () => {
//   const [books, setBooks] = useState([]);

//   //delete book function

//   const deleteBook = async id => {
//     try {
//       const deleteBook = await fetch(`http://localhost:8080/books/${id}`, {
//         method: "DELETE"
//       });

//       setBooks(books.filter(book => book.book_id !== id));
//     } catch (err) {
//       console.error(err.message);
//     }
//   };

//   const getBooks = async () => {
//     try {
//       const response = await fetch("http://localhost:8080/books");
//       const jsonData = await response.json();

//       setBooks(jsonData);
//     } catch (err) {
//       console.error(err.message);
//     }
//   };

//   useEffect(() => {
//     getBooks();
//   }, []);

//   console.log(books);

//   return (
//     <Fragment>
//       {" "}
//       <table class="table mt-5 text-center">
//       <thead>
//           <tr>
//             <th>Title</th>
//             <th>Publication Year</th>
//             <th>Pages</th>
//             <th>Price</th>
//             <th>Edit</th>
//             <th>Delete</th>
//           </tr>
//         </thead>
//         <tbody>
//           {/*<tr>
//             <td>John</td>
//             <td>Doe</td>
//             <td>john@example.com</td>
//           </tr> */}
//           {books.map(book => (
//             <tr key={book.book_id}>
//               <td>{book.description}</td>
//               <td>
//                 <EditBook book={book} />
//               </td>
//               <td>
//                 <button
//                   className="btn btn-danger"
//                   onClick={() => deleteBook(book.book_id)}
//                 >
//                   Delete
//                 </button>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </Fragment>
//   );
// };

// export default ListBooks;
