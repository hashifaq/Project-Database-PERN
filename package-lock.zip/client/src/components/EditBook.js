import React, { Fragment, useState } from "react";

const EditBook = ({ book }) => {
  const [title, setTitle] = useState(book.title);
  const [publication_year, setPublication_year] = useState(book.publication_year);
  const [num_pages, setNum_pages] = useState(book.num_pages);
  const [price, setPrice] = useState(book.price);

  const updateBook = async (e) => {
    e.preventDefault();
    try {
      const body = { title, publication_year, num_pages, price };
      const response = await fetch(`http://localhost:8080/books/${book.book_id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      window.location = "/";
    } catch (err) {
      console.error(err.message);
    }
  };

  return (
    <Fragment>
      <button
        type="button"
        className="btn"
        data-toggle="modal"
        style={{ backgroundColor: '#5DC580', color: 'white' }}
        data-target={`#id${book.book_id}`}
      >
        Edit
      </button>

      <div className="modal" id={`id${book.book_id}`}>
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title">Edit Book</h4>
              <button type="button" className="close" data-dismiss="modal">
                &times;
              </button>
            </div>

            <div className="modal-body">
              <input
                type="text"
                className="form-control"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
              <input
                type="text"
                className="form-control"
                value={publication_year}
                onChange={(e) => setPublication_year(e.target.value)}
              />
              <input
                type="text"
                className="form-control"
                value={num_pages}
                onChange={(e) => setNum_pages(e.target.value)}
              />
              <input
                type="text"
                className="form-control"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
              />
            </div>

            <div className="modal-footer">
              <button
                type="button"
                className="btn"
                style={{ backgroundColor: '#5DC580', color: 'white' }}
                onClick={(e) => updateBook(e)}
              >
                Edit
              </button>
              <button type="button" className="btn btn-danger" data-dismiss="modal">
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </Fragment>
  );
};

export default EditBook;

