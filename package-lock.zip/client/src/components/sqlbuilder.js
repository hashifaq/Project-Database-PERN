import { useState } from 'react'

const SqlBuilder = () => {
  const [query, setQuery] = useState([])
  const [result, setResult] = useState('');
  const Querybuild = async () => {
    try {
      const res = await fetch("http://localhost:8080/execute_queries",{
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({queries: query })
    });
    console.log(JSON.stringify({queries: query }));
      
      if(!res.ok){
        throw new Error('Failed to fetch!');
      }
      const data = await res.json();
      console.log(JSON.stringify({queries: query }));
      setResult(data);
      console.log(data);
    } catch (err) {
      console.error(err.message);
      setResult(err.message);
    }
  };

  const handleSubmitQuery = (e) => {
    e.preventDefault();
    Querybuild();
  };

  return (
    <div className="text-center">
      <h1 className="text-black font-bold text-xl mt-20">SQL BUILDER</h1>
      <form onSubmit={handleSubmitQuery} className="mt-4">
        <div className="flex justify-center">
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            type="text"
            placeholder="masukan query disini"
            className="input-lg w-full rounded-lg p-4"
          ></textarea>
        </div>
        <div className="flex justify-center mt-2">
          <button className="btn btn-primary" type="submit">Execute</button>
        </div>
      </form>
      <div className="mt-4">
        <pre className="bg-[#403c3c] text-black w-full h-[500px] overflow-auto rounded-lg p-8">{JSON.stringify(result, null, 2)}</pre>
      </div>
    </div>


  )
}

export default SqlBuilder